﻿if (typeof apiBaseURL === 'undefined') {
    var apiBaseURL = 'http://localhost:8088/service/'
}
