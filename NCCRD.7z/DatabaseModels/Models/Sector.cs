﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCCRD.Database.Models
{
    [Table("Sector")]
    public class Sector
    {
        public int SectorId { get; set; }

        [Required]
        public string Value { get; set; }

        [Required]
        public int SortOrder { get; set; }

        public bool DefaultValue { get; set; }

        public bool Disabled { get; set; }

        [Required]
        public SectorType SectorType { get; set; }

        public Sector ParentSector { get; set; }

        public ICollection<Project> Projects { get; set; }
        public ICollection<MAOption> MAOptions { get; set; }
    }
}
