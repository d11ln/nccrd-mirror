﻿if (typeof apiBaseURL === 'undefined') {
    var apiBaseURL = 'http://localhost:58683/';
}

if (typeof selectedProjectId === 'undefined') {
    var selectedProjectId = 0;
}

if (typeof titlePart === 'undefined') {
    var titlePart = "";
}

if (typeof statusId === 'undefined') {
    var statusId = 0;
}

if (typeof regionId === 'undefined') {
    var regionId = 0;
}

if (typeof sectorId === 'undefined') {
    var sectorId = 0;
}

if (typeof typologyId === 'undefined') {
    var typologyId = 0;
}