﻿
function load_list() {
    $("#project_list").load("partial_project_list.html");
}