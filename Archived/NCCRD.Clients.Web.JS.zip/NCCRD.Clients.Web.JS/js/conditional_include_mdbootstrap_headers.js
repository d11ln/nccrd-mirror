﻿if (typeof headers_loaded === 'undefined' || headers_loaded !== true) {
    var headers_loaded = true;
    document.write('<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">');
    document.write('<meta http-equiv="x-ua-compatible" content="ie=edge">');
    document.write('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">');
    document.write('<link href="css/bootstrap.min.css" rel="stylesheet">');
    document.write('<link href="css/mdb.min.css" rel="stylesheet">');
    document.write('<link href="css/style.css" rel="stylesheet">');
}