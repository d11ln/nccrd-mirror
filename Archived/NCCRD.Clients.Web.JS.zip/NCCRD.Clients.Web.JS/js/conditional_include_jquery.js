﻿if (typeof jquery_loaded === 'undefined' || jquery_loaded !== true) {
    var jquery_loaded = true;
    document.write("<script type='text/javascript' src='js/jquery-3.2.1.min.js'></script>");
}
