﻿if (typeof knockout_loaded === 'undefined' || knockout_loaded !== true) {
    var knockout_loaded = true;
    $("head").append('<script src="' + 'js/knockout-3.4.2.js' + '"></script>');
}
