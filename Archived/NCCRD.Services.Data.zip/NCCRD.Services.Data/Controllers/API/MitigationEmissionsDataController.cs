﻿using NCCRD.Database.Models;
using NCCRD.Database.Models.Contexts;
using NCCRD.Services.Data.Classes;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace NCCRD.Services.Data.Controllers.API
{
    /// <summary>
    /// Manage MitigationEmissions data
    /// </summary>
    public class MitigationEmissionsDataController : ApiController
    {
        /// <summary>
        /// Get all MitigationEmissionsData data
        /// </summary>
        /// <returns>MitigationEmissionsData data as JSON</returns>
        [HttpGet]
        [Route("api/MitigationEmissionsData/GetAll")]
        public IEnumerable<MitigationEmissionsData> GetAll()
        {
            List<MitigationEmissionsData> data = new List<MitigationEmissionsData>();

            using (var context = new SQLDBContext())
            {
                data = context.MitigationEmissionsData.ToList();
            }

            return data;
        }

        /// <summary>
        /// Get MitigationEmissionsData by Id
        /// </summary>
        /// <param name="id">The Id of the MitigationEmissionsData to get</param>
        /// <returns>MitigationEmissionsData data as JSON</returns>
        [HttpGet]
        [Route("api/MitigationEmissionsData/GetByID/{id}")]
        public MitigationEmissionsData GetByID(int id)
        {
            MitigationEmissionsData data = null;

            using (var context = new SQLDBContext())
            {
                data = context.MitigationEmissionsData.FirstOrDefault(x => x.MitigationEmissionsDataId == id);
            }

            return data;
        }

        /// <summary>
        /// Get MitigationEmissionsData by ProjectId
        /// </summary>
        /// <param name="projectId">The ProjectId of the MitigationEmissionsData to get</param>
        /// <returns>MitigationEmissionsData data as JSON</returns>
        [HttpGet]
        [Route("api/MitigationEmissionsData/GetByProjectID/{projectId}")]
        public List<MitigationEmissionsData> GetByProjectID(int projectId)
        {
            List<MitigationEmissionsData> data = new List<MitigationEmissionsData>();

            using (var context = new SQLDBContext())
            {
                data = context.MitigationEmissionsData.Where(x => x.ProjectId == projectId).OrderBy(x => x.Year).ToList();
            }

            return data;
        }

        /// <summary>
        /// Add MitigationEmissionsData
        /// </summary>
        /// <param name="mitigationEmissionsData">The MitigationEmissionsData to add</param>
        /// <returns>True/False</returns>
        [HttpPost]
        [Route("api/MitigationEmissionsData/AddOrUpdate")]
        [Authorize]
        public bool AddOrUpdate([FromBody]MitigationEmissionsData mitigationEmissionsData)
        {
            bool result = false;

            using (var context = new SQLDBContext())
            {
                mitigationEmissionsData.Project = context.Project.FirstOrDefault(x => x.ProjectId == mitigationEmissionsData.ProjectId);

                var data = context.MitigationEmissionsData.FirstOrDefault(x => x.MitigationEmissionsDataId == mitigationEmissionsData.MitigationEmissionsDataId);
                if (data == null)
                {
                    //Add MitigationEmissionsData entry
                    context.MitigationEmissionsData.Add(mitigationEmissionsData);
                }
                else
                {
                    data.Year = mitigationEmissionsData.Year;
                    data.CO2 = mitigationEmissionsData.CO2;
                    data.CH4 = mitigationEmissionsData.CH4;
                    data.CH4_CO2e = mitigationEmissionsData.CH4_CO2e;
                    data.N2O = mitigationEmissionsData.N2O;
                    data.N2O_CO2e = mitigationEmissionsData.N2O_CO2e;
                    data.HFC = mitigationEmissionsData.HFC;
                    data.HFC_CO2e = mitigationEmissionsData.HFC_CO2e;
                    data.PFC = mitigationEmissionsData.PFC;
                    data.PFC_CO2e = mitigationEmissionsData.PFC_CO2e;
                    data.SF6 = mitigationEmissionsData.SF6;
                    data.SF6_CO2e = mitigationEmissionsData.SF6_CO2e;
                    data.Hydro = mitigationEmissionsData.Hydro;
                    data.Hydro_CO2e = mitigationEmissionsData.Hydro_CO2e;
                    data.Tidal = mitigationEmissionsData.Tidal;
                    data.Tidal_CO2e = mitigationEmissionsData.Tidal_CO2e;
                    data.Wind = mitigationEmissionsData.Wind;
                    data.Wind_CO2e = mitigationEmissionsData.Wind_CO2e;
                    data.Solar = mitigationEmissionsData.Solar;
                    data.Solar_CO2e = mitigationEmissionsData.Solar_CO2e;
                    data.FossilFuelElecRed = mitigationEmissionsData.FossilFuelElecRed;
                    data.FossilFuelElecRed_CO2e = mitigationEmissionsData.FossilFuelElecRed_CO2e;
                    data.BioWaste = mitigationEmissionsData.BioWaste;
                    data.BioWaste_CO2e = mitigationEmissionsData.BioWaste_CO2e;
                    data.Geothermal = mitigationEmissionsData.Geothermal;
                    data.Geothermal_CO2e = mitigationEmissionsData.Geothermal_CO2e;
                    data.ProjectId = mitigationEmissionsData.ProjectId;
                    data.Project = mitigationEmissionsData.Project;
                }

                try
                {
                    context.SaveChanges();
                    result = true;
                }
                catch (DbEntityValidationException e)
                {
                    throw new Exception(Utils.ParseDbEntityValidationException(e));
                }
            }

            return result;
        }
    }
}