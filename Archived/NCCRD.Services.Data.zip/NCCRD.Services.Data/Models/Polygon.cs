﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NCCRD.Services.Data.Models
{
    public class Polygon
    {
        public string polygon { get; set; }
    }
}